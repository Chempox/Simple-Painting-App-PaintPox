import tkinter
from tkinter import *
from tkinter import filedialog
from tkinter import colorchooser
import pyautogui as gui
from PIL import ImageTk, Image, ImageGrab
import sys
eraser_default = 'white'
###########Global###############
current_x,current_y = 0,0
default_color ="black"
default_color_1 = "black"
default_color_2 = "white"
eraser_default = "white"
width_x = 5
width_eraser_x = 5
##########Functions################
def new_canvas():
    canvas.delete("all")

def save_file():
    result = filedialog.asksaveasfilename(initialdir="/", title="Select file", filetypes=[('PNG','*.png')])

    if result:
        x = canvas.winfo_rootx()
        y = canvas.winfo_rooty()
        height = canvas.winfo_height() + y
        width = canvas.winfo_width() + x
        ImageGrab.grab().crop((x, y, width, height)).save(result + ".png")


def lineCreate(event):
    global current_x,current_y,width_x
    canvas.create_oval((current_x,current_y,event.x,event.y),fill = default_color, outline= default_color, width = width_x)
    current_x, current_y = event.x,event.y


def eraseLine(event):
    global current_x,current_y
    canvas.create_oval((current_x,current_y,event.x,event.y),fill = eraser_default, outline= eraser_default, width = width_eraser_x)
    current_x, current_y = event.x,event.y


def locate_xy(event):
    global current_x,current_y
    current_x,current_y=event.x,event.y

def draw():
    canvas.bind('<Button-1>',locate_xy)
    canvas.bind('<B1-Motion>',lineCreate)

def erase():
    canvas.bind('<Button-1>',locate_xy)
    canvas.bind('<B1-Motion>',eraseLine)

def change_color_1():
    global default_color
    global default_color_1
    color_1.config(bg = default_color_1)
    default_color = default_color_1

def change_color_2():
    global default_color
    global default_color_2
    color_2.config(bg = default_color_2)
    default_color = default_color_2

def color_picker_1(event):
    global default_color
    global default_color_1
    default_color_1 = colorchooser.askcolor()[1]
    default_color = default_color_1
def color_picker_2(event):
    global default_color
    global default_color_2
    default_color_2 = colorchooser.askcolor()[1]
    default_color = default_color_2

def pencil_size(event):
    def size_confirm():
        global width_x
        width_x = size.get()
        window_pop.destroy()
    window_pop = Tk()
    px_size = Label(window_pop, text = "Brush Size::", width = 30)
    px_size.pack()
    size = Entry(window_pop, width = 30, borderwidth = 15)
    size.pack()
    enter_button = Button(window_pop, text = "Confirm",command = size_confirm)
    enter_button.pack()
    window_pop.mainloop()

def eraser_size(event):
    def size_confirm():
        global width_eraser_x
        width_eraser_x = size.get()
        window_pop.destroy()
    window_pop = Tk()
    px_size = Label(window_pop, text = "Brush Size::", width = 30)
    px_size.pack()
    size = Entry(window_pop, width = 30, borderwidth = 15)
    size.pack()
    enter_button = Button(window_pop, text = "Confirm",command = size_confirm)
    enter_button.pack()
    window_pop.mainloop()
def stop(event):
    pass
def getPixelColor():
    window.bind("<Button-1>", callback)
def callback(event):
    global default_color
    global default_color_1
    x, y = gui.position()
    image = gui.screenshot(region=(x,y, 1, 1))
    color = image.getpixel((0, 0))
    z = ('#{0:02x}{1:02x}{2:02x}'.format(*color))
    default_color_1 = z
    default_color = default_color_1
    print(z)
    window.bind("<Button-1>", stop)
###########Initializer###############
window = Tk()
window.title('Draw-V1')
window.state("zoomed")
window.config(bg='grey')

topMenu = Menu(window)
window.config(menu=topMenu)
submenu = Menu(topMenu, tearoff = 0)

topMenu.add_cascade(label='File',menu=submenu)
submenu.add_command(label = 'New Canavas', command = new_canvas)
submenu.add_command(label = "Save", command = save_file)

#########Canvas##############
canvas=Canvas(window, width = 1280, height = 720)
canvas.place(relx = 0.5, rely = 0.5, anchor=CENTER)
canvas.config(bg="white")



#########images########
pencil = Image.open("toolbox_images/pencil_1.png")
resized = pencil.resize((22,22), Image.ANTIALIAS)
pencil_resized = ImageTk.PhotoImage(resized)
pencil_label = Label(image = pencil_resized)

eraser = Image.open("toolbox_images/eraser_1.png")
resized_e = eraser.resize((22,22), Image.ANTIALIAS)
eraser_resized = ImageTk.PhotoImage(resized_e)
eraser_label = Label(image = eraser_resized)

bucket = Image.open("toolbox_images/bucket_1.png")
resized_b = bucket.resize((22,22), Image.ANTIALIAS)
bucket_resized = ImageTk.PhotoImage(resized_b)
bucket_label = Label(image = bucket_resized)

dropper = Image.open("toolbox_images/dropper_1.png")
resized_p = dropper.resize((22,22), Image.ANTIALIAS)
dropper_resized = ImageTk.PhotoImage(resized_p)
dropper_label = Label(image = dropper_resized)

##########Label Declaration##################
spacing_y1 = Label(window, text = "", bg = "grey")
spacing_y2 = Label(window, text = "", bg = "grey")
spacing_x1 = Label(window, text = "     ", bg = "grey")
spacing_x2 = Label(window, text = "     ", bg = "grey")

color_1 = tkinter.Button(window, text = '', width = 2, height = 1, bg = "black", command = change_color_1)
color_1.bind("<Double-Button-1>",color_picker_1)


color_2 = tkinter.Button(window, text = '', width = 2, height = 1, bg = "white", command = change_color_2)
color_2.bind("<Double-Button-1>",color_picker_2)

pencil_button = tkinter.Button(window, pencil_label, width = 20, height = 20, command = draw)
pencil_button.bind("<Double-Button-1>",pencil_size)

eraser_button = tkinter.Button(window, eraser_label, width = 20, height = 20, command = erase)
eraser_button.bind("<Double-Button-1>",eraser_size)

bucket_button = tkinter.Button(window, bucket_label, width = 20, height = 20)
dropper_button = tkinter.Button(window, dropper_label, width = 20, height = 20, command = getPixelColor )


spacing_x1.grid(row = 0, column = 0)
spacing_y1.grid(row = 0, column = 1)
spacing_y2.grid(row = 1, column = 1)
pencil_button.grid(row = 3, column  =2)
eraser_button.grid(row = 3, column = 1)
dropper_button.grid(row = 4, column = 1)
bucket_button.grid(row = 4, column = 2)

color_1.grid(row = 5, column = 1)
color_2.grid(row = 5, column = 2)



window.mainloop()
